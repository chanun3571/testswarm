# Arobota-MobileRobot

Autonomous 2-wheel mobile robot with rplidarS1 using ROS to handle navigation and path-planning 
connecting with STM32 to drive motors with PD control

- Mainrobot.launch for navigation on Rviz
- Gmapping.launch for create map from lidar by hector-slam package


- Moverobot.py for sending action massage moving robot to target positions
